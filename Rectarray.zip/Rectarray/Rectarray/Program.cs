﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rectarray
{
    class Program
    {
        static void Main(string[] args)
        {
         
            int n = Convert.ToInt32(Console.ReadLine());
            int[, ,] a = new int[2, 2, 2];
            {
                a[0, 0, 0] = 1;
                a[0, 0, 1] = 2;
                a[0, 1, 0] = 3;
                a[0, 1, 1] = 4;
                a[1, 0, 1] = 5;
                a[1, 0, 0] = 6;
                a[1, 1, 0] = 7;
                a[1, 1, 1] = 8;

                foreach (int i in a)
                {
                    Console.Write(i + " ");
                }
                Console.Read();

            }
        }
    }
}
