﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace conditional
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter your actual age:");
            int age = Convert.ToInt32(Console.ReadLine());
            if (age > 0)
            {
                if (age >= 18 && age < 80)
                {
                    Console.Write("Adult");
                }
                else if (age < 18)
                {
                    Console.Write("Teenage");
                }
                else if (age >= 60)
                {
                    Console.Write("Senior citizon");
                }
                else
                {
                    Console.Write("birth pending");
                }
            }
            Console.Read();
        }
    }
}
