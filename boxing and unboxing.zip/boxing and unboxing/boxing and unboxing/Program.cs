﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxing_and_unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 10;         //boxing
            object obj = i;
            Console.WriteLine(obj);

            int j = (int)obj;   //unboxing
            Console.Write(j);
            Console.Read();
        }
    }
}
