﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace do_while_pyramid
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter any number:=");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, o = 2, p = 3,k=1;
            do
            {
                int j = 1;
                do
                {

                    if (k <= 3)
                    {
                        Console.Write(k + " ");

                    }
                    else
                    {
                        k = o * p;
                        if (k > n)
                        {
                            break;
                        }
                        Console.Write(k + " ");
                        o = p;
                        p = k;
                    }
                    k++;
                    j++;
                } while (j <= i);
                i++;
                if (k > n)
                {
                    break;
                }
                Console.WriteLine();
            } while (i <= n);
            Console.Read();
        }
    }
}
