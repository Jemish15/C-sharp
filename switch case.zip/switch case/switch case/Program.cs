﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace switch_case
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("press 1 for Blue BG : ");
            Console.WriteLine("press 2 for White BG : ");
            Console.WriteLine("press 3 for Green BG : ");

            int n = Convert.ToInt32(Console.ReadLine());

            switch (n)
            {
                case 1: Console.BackgroundColor = ConsoleColor.Blue;
                    Console.Clear();
                    break;

                case 2: Console.BackgroundColor = ConsoleColor.White;
                    Console.Clear();
                    break;

                case 3: Console.BackgroundColor = ConsoleColor.Green;
                    Console.Clear();
                    break;

                default: Console.Write("! Enter Correct number !");
                    break;

            }
            Console.ReadKey();
        }
    }
}
